echo $1 | ace -g mar.dat -f 2>/dev/null
