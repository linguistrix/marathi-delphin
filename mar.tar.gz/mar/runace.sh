ace -G mar.dat -g ace/config.tdl
